package com.example.wordlegame

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.widget.Toast

class DatabaseHelper(private val context: Context):
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
    companion object {
        private const val DATABASE_NAME = "WordleDatabase.db"
        private const val DATABASE_VERSION = 7 // Increment the version if you are modifying the schema
        private const val TABLE_NAME = "data"
        private const val COLUMN_ID = "id"
        private const val COLUMN_USERNAME = "username"
        private const val COLUMN_PASSWORD = "password"
        private const val COLUMN_SCORE = "score"
    }

    override fun onCreate(db: SQLiteDatabase?) {
        val createTableQuery = "CREATE TABLE $TABLE_NAME " +
                "($COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COLUMN_USERNAME TEXT, " +
                "$COLUMN_PASSWORD TEXT, " +
                "$COLUMN_SCORE INTEGER DEFAULT 0)"
        db?.execSQL(createTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db?.execSQL("ALTER TABLE $TABLE_NAME ADD COLUMN $COLUMN_SCORE INTEGER DEFAULT 0")
        }
    }

    fun updateUserScore(username: String, score: Int): Int {
        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(COLUMN_SCORE, score)
        db.update(TABLE_NAME, contentValues, "$COLUMN_USERNAME = ?", arrayOf(username))
        return getUserScore(username)
    }

    fun getUserScore(username: String): Int {
        val db = this.readableDatabase
        val cursor = db.rawQuery("SELECT $COLUMN_SCORE FROM $TABLE_NAME WHERE $COLUMN_USERNAME = ?", arrayOf(username))
        var score = 0
        if (cursor.moveToFirst()) {
            val columnIndex = cursor.getColumnIndex(COLUMN_SCORE)
            if (columnIndex != -1) {
                score = cursor.getInt(columnIndex)
            }
        }
        cursor.close()
        return score
    }

    fun insertUser(username: String, password: String): Long {
        val values = ContentValues().apply {
            put(COLUMN_USERNAME, username)
            put(COLUMN_PASSWORD, password)
        }
        val db = writableDatabase
        return db.insert(TABLE_NAME, null, values)
    }

    fun readUser(username: String, password: String): Boolean {
        val db = readableDatabase
        val selection = "$COLUMN_USERNAME = ? AND $COLUMN_PASSWORD = ?"
        val selectionArgs = arrayOf(username, password)
        val cursor = db.query(TABLE_NAME, null, selection, selectionArgs, null, null, null)
        val userExists = cursor.count > 0
        cursor.close()
        return userExists
    }

    fun getUsernamesFromDatabase(): List<User> {
        val users = mutableListOf<User>()
        val db = readableDatabase
        val cursor = db.query(TABLE_NAME, arrayOf(COLUMN_USERNAME, COLUMN_PASSWORD, COLUMN_SCORE), null, null, null, null, null)

        with(cursor) {
            while (moveToNext()) {
                val username = getString(getColumnIndexOrThrow(COLUMN_USERNAME))
                val password = getString(getColumnIndexOrThrow(COLUMN_PASSWORD))
                val score = getInt(getColumnIndexOrThrow(COLUMN_SCORE))
                users.add(User(username, password, score))
            }
        }
        cursor.close()
        return users
    }

    fun isUsernameExists(username: String): Boolean {
        val db = this.readableDatabase
        val cursor = db.query(
            "data", // Nome da tabela
            arrayOf("username"), // Colunas a serem retornadas
            "username = ?", // Coluna para a cláusula WHERE
            arrayOf(username), // Valores para a cláusula WHERE
            null, // Group by
            null, // Having
            null // Order by
        )
        val exists = cursor.count > 0
        cursor.close()
        db.close()
        return exists
    }

    fun deleteUserById(userId: Int): Boolean {
        val db = this.writableDatabase
        val result = db.delete(TABLE_NAME, "$COLUMN_ID = ?", arrayOf(userId.toString()))
        db.close()
        return result > 0
    }
}