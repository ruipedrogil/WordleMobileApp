package com.example.wordlegame

class Dicionario {

    val arrayPalavras5PT = "amigo, feliz, livro, praia, rosto, saude, verde, vento, vozes, bisco, cacto, dente, " +
                           "gente, hotel, forte, jovem, lapis, manga, nuvem, olhos, papel, queda, mosca, sabor, tigre, urano, vapor, amora, zebra, mundo, novos, firme, doido, grito, vazio, longe, "  +
                           "brisa, limpo, limao, lutar, tenso, fruta, beijo, sinal, " +
                           "navio, saida, lento, exato, bater, salto, anjos, fundo, roupa, " +
                           "moeda, farda, copa, fases, baile, preso, ligar, ficha, soldo, trave, mural, dados, fossa, moral, forro, pasto, " +
                           "danca, curva, plena, prado, peixe, canto, botas, fraco, rente, cheia, " +
                           "surto, roubo, extra, risco, poema, etapa, cegar, cargo, porta, zorro, forno, carro, causa, " +
                           "dever, xibiu, sendo, estar, brado, tenaz, coser, pária, genro, ainda, posse, crivo, temor, comum, prole, forma, " +
                           "apraz, servo, ajuda, prosa, falar, tenro, desse, pífio, legal, certo, presa, posso, cunho, vendo, viril, ontem, " +
                           "devir, fonte, marco, ponto, igual, labor, feixe, amplo, terno, lavra, remir"

    val arrayPalavras4PT = "amor,vida,mare,flor,casa,pato,lado,maca,alma,rede,fase,peao,"+
                           "puro,azar,joia,ruim,alto,veia,fino,belo,neve,ouro,bola,coro," +
                           "nato,dura,raiz,real,cura,muro,mesa,raro,leve,pais," +
                           "meta,fera,base,pois,lira,dado,roda,voar,cena,lido,cama,auto,logo," +
                           "voga,deus,onde,arte,sido,jugo,ante,cedo,rima,meio,traz,numa,sela," +
                           "isso,cujo,noia,cela,sair,teor,face,asco,nojo,alvo,foco"

    val arrayPalavras6PT = "amigos,correr,flores,sonhar,brilho,ventos,selvas,grande,claras," +
                           "forças,prazer,mundos,campos,folhas,acesso,pontas,vendas,cartas," +
                           "beleza,cantos,pistas,novela,frutas,cheiro,mentes,cobrir,praias," +
                           "cravos,poetas,cargos,roupas,viagem,acorde,beijos,ligado,chuvas," +
                           "fardas,doceza,tardes,lembar,sorris,alegre,dancar,nuvens,passar,fardas,doceza,tardes,lembar,sorris,alegre,dancar,nuvens,passar,insano," +
                           "ciente,asseio,esmero,diante,ironia,enxuto,faceta,vedado,origem,melhor," +
                           "formos,cingir,passar,aludir,porfia,cessar,beleza,emanar,herege,coagir," +
                           "arguir,decoro,estima,lacuna,brando,adorar,pessoa,franco,limite,viagem," +
                           "maroto,sereno,triste,jamais,emitir,piegas,acordo,exalar,forjar,frugal," +
                           "vermos,evocar,súbito,social,condiz,galgar,querer"

}