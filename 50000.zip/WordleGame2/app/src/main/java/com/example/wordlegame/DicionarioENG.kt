package com.example.wordlegame

class DicionarioENG {
    val arrayPalavras5EN =
        "apple, table, chair, house, mouse, clock, phone, light, water, bread, knife, spoon, fork, plate, glass, watch, shoes, socks, shirt, pants, dress, skirt, glove, scarf, mixer, juice, cider, sugar, truck, plane, train, motor, radio, music, movie, paper, ruler"

    val arrayPalavras4EN =  "love, life, time, work, play, game, book, tree, bird, fish, star, moon, rain, snow, wind, fire, snow, cold, warm, cool, fast, slow, high, deep, wide, long, tall, thin, rich, poor, good, hard, soft, loud, dark, easy, safe, ugly, fast, slow"

    val arrayPalavras6EN = "apple, bottle, garden, simple, spring, friend, jungle, pocket, planet, purple, desert, coffee, frozen, mirror, orange, window, flight, leader, monkey, writer, shadow, bridge, legend, spider, wisdom, mother, father, animal, pretty, office, rabbit, farmer, secret, violin, always, danger, author, camera, middle, forest, summer, beauty, island, driver, engine, silver, volume, castle, shadow, artist, genius, monkey, strike"
}