package com.example.wordlegame

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class DificuldadeView : AppCompatActivity() {
    var pontuacao = 0
    private lateinit var username: String
    private lateinit var databaseHelper: DatabaseHelper
    private val REQUEST_CODE_FACIL = 1
    private val REQUEST_CODE_MEDIO = 2
    private val REQUEST_CODE_DIFICIL = 3
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_dificuldade_view)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        databaseHelper = DatabaseHelper(this)
        username = intent.getStringExtra("user") ?: "default_user"
        pontuacao = databaseHelper.getUserScore(username)

        // Exibir a pontuação acumulada
        val pontuacaoTextView = findViewById<TextView>(R.id.points)
        pontuacaoTextView.text = "Pontuação: $pontuacao"


        findViewById<Button>(R.id.buttonFacil).setOnClickListener {
            val intent = Intent(this, WordleEasy::class.java)
            intent.putExtra("username", username)
            intent.putExtra("pontos", pontuacao)
            startActivityForResult(intent, REQUEST_CODE_FACIL)
        }

        findViewById<Button>(R.id.buttonMedio).setOnClickListener {
            val intent = Intent(this, Wordle::class.java)
            intent.putExtra("username", username)
            intent.putExtra("pontos", pontuacao)
            startActivityForResult(intent, REQUEST_CODE_MEDIO)
        }

        findViewById<Button>(R.id.buttonDificil).setOnClickListener {
            val intent = Intent(this, WordleHard::class.java)
            intent.putExtra("username", username)
            intent.putExtra("pontos", pontuacao)
            startActivityForResult(intent, REQUEST_CODE_DIFICIL)
        }

        findViewById<ImageView>(R.id.imageView).setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("user", username)
            intent.putExtra("pontos", pontuacao)
            startActivity(intent)
            finish()
        }

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            val pontos = data?.getIntExtra("pontos", databaseHelper.getUserScore(username)) ?: 0
            pontuacao = pontos
            saveScore()
            val pontuacaoTextView = findViewById<TextView>(R.id.points)
            pontuacaoTextView.text = "Pontuação: $pontuacao"
        }
    }

    private fun saveScore() {
        databaseHelper.updateUserScore(username, pontuacao)
    }
}
