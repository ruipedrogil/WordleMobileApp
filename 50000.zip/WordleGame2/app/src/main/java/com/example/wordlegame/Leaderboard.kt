package com.example.wordlegame

import android.content.Intent
import android.os.Bundle
import android.widget.TableRow
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.wordlegame.databinding.ActivityLeaderboardBinding

class Leaderboard : AppCompatActivity() {
    private lateinit var binding: ActivityLeaderboardBinding
    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityLeaderboardBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        dbHelper = DatabaseHelper(this)

        // Obter a pontuação e o username passados pela DificuldadeView
        val pontuacao = intent.getIntExtra("pontos", 0)
        val username = intent.getStringExtra("user") ?: "default_user"

        binding.imageView.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("user", username)
            startActivity(intent)
        }

        // Atualizar a pontuação do utilizador na base de dados
        dbHelper.getUserScore(username)

        // Obter os usernames e pontuações da base de dados
        val users = dbHelper.getUsernamesFromDatabase().sortedByDescending{ dbHelper.getUserScore(it.username) }

        // Adicionar cada username e pontuação como uma nova linha na tabela
        for (user in users) {
            val pontos = dbHelper.getUserScore(user.username)
            val tableRow = TableRow(this)
            val usernameTextView = TextView(this)
            val scoreTextView = TextView(this)

            usernameTextView.text = user.username
            usernameTextView.setTextColor(resources.getColor(R.color.white))
            usernameTextView.layoutParams = TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f)

            scoreTextView.text = pontos.toString()
            scoreTextView.setTextColor(resources.getColor(R.color.white))
            scoreTextView.layoutParams = TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f)

            tableRow.addView(usernameTextView)
            tableRow.addView(scoreTextView)
            binding.tableLayout.addView(tableRow)
        }
    }
}