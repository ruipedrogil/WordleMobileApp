package com.example.wordlegame

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.CheckBox
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.wordlegame.databinding.ActivityLinguaBinding


class Lingua : AppCompatActivity() {
    private lateinit var binding: ActivityLinguaBinding
    lateinit var CheckPT: CheckBox
    lateinit var CheckEN: CheckBox
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityLinguaBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        CheckPT = binding.checkBoxPT
        CheckEN = binding.checkBoxEN

        val sharedPreferences = getSharedPreferences("LinguaPrefs", Context.MODE_PRIVATE)
        CheckPT.isChecked = sharedPreferences.getBoolean("isCheckedPT", false)
        CheckEN.isChecked = sharedPreferences.getBoolean("isCheckedEN", false)

        CheckEN.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                binding.checkBoxPT.isChecked = false
            }
        }
        CheckPT.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                binding.checkBoxEN.isChecked = false
            }
        }
        binding.imageView.setOnClickListener {
            val editor = sharedPreferences.edit()
            editor.putBoolean("isCheckedPT", CheckPT.isChecked)
            editor.putBoolean("isCheckedEN", CheckEN.isChecked)
            editor.apply()

            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("isCheckedPT", CheckPT.isChecked)
            intent.putExtra("isCheckedEN", CheckEN.isChecked)
            startActivity(intent)
        }
    }
}