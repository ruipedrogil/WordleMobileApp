package com.example.wordlegame

import android.os.Bundle
import android.widget.Toast
import android.content.Intent
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.wordlegame.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var databaseHelper: DatabaseHelper
    private lateinit var binding: ActivityLoginBinding
    var user: User? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        databaseHelper = DatabaseHelper(this)


        binding.loginButton.setOnClickListener {
            val username = binding.loginUser.text.toString()
            val password = binding.loginPass.text.toString()
            if (username.isNotEmpty() && password.isNotEmpty()) {
                loginDatabase(username, password)
                user = User(username, password, 0)
            } else {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
            }
        }

        binding.signRedirect.setOnClickListener {
            val intent = Intent(this, SignupActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun loginDatabase(username: String, password: String) {
        val userExists = databaseHelper.readUser(username, password)
        if (userExists) {
            Toast.makeText(this, "Login com sucesso", Toast.LENGTH_SHORT).show()


            val currentUsername = username // Usar o logged username
            val pontuacao = databaseHelper.getUserScore(username) // Vai buscar o score atual

            Intent(this, MainActivity::class.java).apply {
                putExtra("user", currentUsername)
                putExtra("pontos", pontuacao)
                startActivity(this)
            }
            finish()
        } else {
            Toast.makeText(this, "Erro, esse user não existe", Toast.LENGTH_SHORT).show()
        }
    }
}