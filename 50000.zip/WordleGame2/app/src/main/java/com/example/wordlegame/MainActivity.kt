package com.example.wordlegame

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.wordlegame.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var username: String
    private var pontuacao = 0
    private lateinit var databaseHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        databaseHelper = DatabaseHelper(this)
        username = intent.getStringExtra("user") ?: "default_user"
        pontuacao = databaseHelper.getUserScore(username)

        findViewById<Button>(R.id.butLogOut).setOnClickListener() {
            Toast.makeText(this, "Log out feito com sucesso", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

        findViewById<Button>(R.id.butJogar).setOnClickListener() {
            val intent = Intent(this, DificuldadeView::class.java)
            intent.putExtra("user", username)
            //intent.putExtra("pontos", pontuacao)
            startActivity(intent)
        }

        findViewById<Button>(R.id.butRules).setOnClickListener() {
            val intent = Intent(this, Regras::class.java)
            startActivity(intent)
        }

        findViewById<Button>(R.id.butLang).setOnClickListener(){
            val intent = Intent(this, Lingua::class.java)
            startActivity(intent)
        }

        findViewById<Button>(R.id.butLead).setOnClickListener(){
            val intent = Intent(this, Leaderboard::class.java)
            intent.putExtra("user", username)
            startActivity(intent)
        }
    }
}