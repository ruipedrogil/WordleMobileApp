package com.example.wordlegame

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.wordlegame.databinding.ActivitySignupBinding

class SignupActivity : AppCompatActivity() {

    private lateinit var databaseHelper: DatabaseHelper
    private lateinit var binding: ActivitySignupBinding
    //private val userIdToDelete = 4 // Substitua pelo ID do usuário que deseja remover

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        databaseHelper = DatabaseHelper(this)
        //databaseHelper.deleteUserById(userIdToDelete)


        binding.signButton.setOnClickListener {
            val username = binding.signUser.text.toString()
            val password = binding.signPass.text.toString()
            if (username.isNotEmpty() && password.isNotEmpty()) {
                signupDatabase(username, password)
                User(username, password, 0)
            } else {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
            }
        }

        binding.loginRedirect.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun signupDatabase(username: String, password: String) {
        if(password.length < 8){
            Toast.makeText(this, "A password tem de ter pelo menos 6 caracteres", Toast.LENGTH_SHORT).show()
        } else
        if (databaseHelper.isUsernameExists(username)) {
            Toast.makeText(this, "Erro, já existe esse username", Toast.LENGTH_SHORT).show()
        } else {
            val insertedRow = databaseHelper.insertUser(username, password)
            if (insertedRow != -1L) {
                Toast.makeText(this, "Signup com sucesso", Toast.LENGTH_SHORT).show()
                val intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "Erro ao fazer signup", Toast.LENGTH_SHORT).show()
            }
        }
    }
}