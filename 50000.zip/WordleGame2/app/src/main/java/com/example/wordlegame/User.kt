package com.example.wordlegame

import java.io.Serializable

data class User(val username: String, val password: String,  val score: Int)
    : Serializable