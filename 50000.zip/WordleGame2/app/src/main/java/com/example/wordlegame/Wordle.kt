package com.example.wordlegame

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.wordlegame.databinding.ActivityWordleBinding


class Wordle : AppCompatActivity() {
    private lateinit var WORD: String
    private lateinit var binding: ActivityWordleBinding
    private lateinit var username: String
    private lateinit var databaseHelper: DatabaseHelper
    private var count = 0
    private var pontuacao = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityWordleBinding.inflate(layoutInflater)
        setContentView(binding.root)
        databaseHelper = DatabaseHelper(this)
        username = intent.getStringExtra("username") ?: "default_user"
        pontuacao = intent.getIntExtra("pontos",pontuacao)
        val sharedPreferences = getSharedPreferences("LinguaPrefs", Context.MODE_PRIVATE)
        val isCheckedPT = sharedPreferences.getBoolean("isCheckedPT", true)
        val isCheckedEN = sharedPreferences.getBoolean("isCheckedEN", true)
        if (isCheckedPT) {
            WORD = Dicionario().arrayPalavras5PT.split(", ").random()
            Toast.makeText(
                applicationContext,
                "A palavra é: $WORD",
                Toast.LENGTH_SHORT
            ).show()
        } else if (isCheckedEN) {
            WORD = DicionarioENG().arrayPalavras5EN.split(", ").random()
            Toast.makeText(
                applicationContext,
                "The word is: $WORD",
                Toast.LENGTH_SHORT
            ).show()
        }
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        binding.back.setOnClickListener {
            val intent = Intent(this, DificuldadeView::class.java)
            intent.putExtra("username", username)
            intent.putExtra("pontos", pontuacao)
            setResult(RESULT_OK, intent)
            finish()
        }

        binding.MEbut.visibility = View.INVISIBLE
        binding.JNbut.visibility = View.INVISIBLE

        keepPassingFocus()

        binding.box15.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (s?.length == 1) {
                    validateRow(
                        binding.box11,
                        binding.box12,
                        binding.box13,
                        binding.box14,
                        binding.box15,
                        binding.box21
                    )
                }
            }
        })

        binding.box25.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (s?.length == 1) {
                    validateRow(
                        binding.box21,
                        binding.box22,
                        binding.box23,
                        binding.box24,
                        binding.box25,
                        binding.box31
                    )
                }
            }
        })

        binding.box35.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (s?.length == 1) {
                    validateRow(
                        binding.box31,
                        binding.box32,
                        binding.box33,
                        binding.box34,
                        binding.box35,
                        binding.box41
                    )
                }
            }
        })

        binding.box45.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (s?.length == 1) {
                    validateRow(
                        binding.box41,
                        binding.box42,
                        binding.box43,
                        binding.box44,
                        binding.box45,
                        binding.box51
                    )
                }
            }
        })

        binding.box55.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (s?.length == 1) {
                    validateRow(
                        binding.box51,
                        binding.box52,
                        binding.box53,
                        binding.box54,
                        binding.box55,
                        null
                    )
                }
            }
        })

        binding.JNbut.setOnClickListener {
            resetGame()
        }
        binding.MEbut.setOnClickListener() {
            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("user", username)
            startActivity(intent)
        }
    }

    private fun makeGameInactive() {
        binding.box11.isEnabled = false
        binding.box12.isEnabled = false
        binding.box13.isEnabled = false
        binding.box14.isEnabled = false
        binding.box15.isEnabled = false
        binding.box21.isEnabled = false
        binding.box22.isEnabled = false
        binding.box23.isEnabled = false
        binding.box24.isEnabled = false
        binding.box25.isEnabled = false
        binding.box31.isEnabled = false
        binding.box32.isEnabled = false
        binding.box33.isEnabled = false
        binding.box34.isEnabled = false
        binding.box35.isEnabled = false
        binding.box41.isEnabled = false
        binding.box42.isEnabled = false
        binding.box43.isEnabled = false
        binding.box44.isEnabled = false
        binding.box45.isEnabled = false
        binding.box51.isEnabled = false
        binding.box52.isEnabled = false
        binding.box53.isEnabled = false
        binding.box54.isEnabled = false
        binding.box55.isEnabled = false
    }

    private fun validateRow(
        box1: EditText,
        box2: EditText,
        box3: EditText,
        box4: EditText,
        box5: EditText,
        nextBox: EditText?
    ) {
        val box1Txt = box1.text.toString()
        val box2Txt = box2.text.toString()
        val box3Txt = box3.text.toString()
        val box4Txt = box4.text.toString()
        val box5Txt = box5.text.toString()

        val w1 = WORD[0].toString()
        val w2 = WORD[1].toString()
        val w3 = WORD[2].toString()
        val w4 = WORD[3].toString()
        val w5 = WORD[4].toString()

        if (box1Txt == w2 || box1Txt == w3 || box1Txt == w4 || box1Txt == w5) {
            box1.setBackgroundColor(Color.parseColor("#c28904"))
        }
        if (box2Txt == w1 || box2Txt == w3 || box2Txt == w4 || box2Txt == w5) {
            box2.setBackgroundColor(Color.parseColor("#c28904"))
        }
        if (box3Txt == w1 || box3Txt == w2 || box3Txt == w4 || box3Txt == w5) {
            box3.setBackgroundColor(Color.parseColor("#c28904"))
        }
        if (box4Txt == w1 || box4Txt == w2 || box4Txt == w3 || box4Txt == w5) {
            box4.setBackgroundColor(Color.parseColor("#c28904"))
        }
        if (box5Txt == w1 || box5Txt == w2 || box5Txt == w3 || box5Txt == w4) {
            box5.setBackgroundColor(Color.parseColor("#c28904"))
        }

        if (box1Txt == w1) {
            box1.setBackgroundColor(Color.parseColor("#33cc33"))
        }
        if (box2Txt == w2) {
            box2.setBackgroundColor(Color.parseColor("#33cc33"))
        }
        if (box3Txt == w3) {
            box3.setBackgroundColor(Color.parseColor("#33cc33"))
        }
        if (box4Txt == w4) {
            box4.setBackgroundColor(Color.parseColor("#33cc33"))
        }
        if (box5Txt == w5) {
            box5.setBackgroundColor(Color.parseColor("#33cc33"))
        }

        if (box1Txt != w1 && box1Txt != w2 && box1Txt != w3 && box1Txt != w4 && box1Txt != w5) {
            box1.setBackgroundColor(Color.parseColor("#808080"))
        }
        if (box2Txt != w1 && box2Txt != w2 && box2Txt != w3 && box2Txt != w4 && box2Txt != w5) {
            box2.setBackgroundColor(Color.parseColor("#808080"))
        }
        if (box3Txt != w1 && box3Txt != w2 && box3Txt != w3 && box3Txt != w4 && box3Txt != w5) {
            box3.setBackgroundColor(Color.parseColor("#808080"))
        }
        if (box4Txt != w1 && box4Txt != w2 && box4Txt != w3 && box4Txt != w4 && box4Txt != w5) {
            box4.setBackgroundColor(Color.parseColor("#808080"))
        }
        if (box5Txt != w1 && box5Txt != w2 && box5Txt != w3 && box5Txt != w4 && box5Txt != w5) {
            box5.setBackgroundColor(Color.parseColor("#808080"))
        }

        val enteredWord = box1Txt + box2Txt + box3Txt + box4Txt + box5Txt

        if (box1Txt == w1 && box2Txt == w2 && box3Txt == w3 && box4Txt == w4 && box5Txt == w5) {
            binding.Certo.text = "Parabéns! acertou em cheio."
            binding.Certo.visibility = View.VISIBLE
            binding.JNbut.visibility = View.VISIBLE
            binding.MEbut.visibility = View.VISIBLE
            if(count == 0){
                pontuacao += 50
            } else if(count == 1){
                pontuacao += 40
            } else if(count == 2) {
                pontuacao += 30
            } else if(count == 3) {
                pontuacao += 20
            } else if(count == 4){
                pontuacao += 10
            }
            makeGameInactive()
            saveScore()
            Toast.makeText(
                applicationContext,
                "Palavra certa, parabéns!",
                Toast.LENGTH_SHORT
            ).show()
            binding.back.setOnClickListener{
                val resultIntent = Intent()
                resultIntent.putExtra("pontos", pontuacao)
                setResult(RESULT_OK, resultIntent)
                finish()
            }
        }else if (!isWordInDictionary(enteredWord)) {
                Toast.makeText(
                    applicationContext,
                    "A palavra não está no dicionário!",
                    Toast.LENGTH_SHORT
                ).show()
            box1.text.clear()
            box2.text.clear()
            box3.text.clear()
            box4.text.clear()
            box5.text.clear()
            box1.setBackgroundResource(R.drawable.wordle_border)
            box2.setBackgroundResource(R.drawable.wordle_border)
            box3.setBackgroundResource(R.drawable.wordle_border)
            box4.setBackgroundResource(R.drawable.wordle_border)
            box5.setBackgroundResource(R.drawable.wordle_border)
            box1.requestFocus()
            } else {
            Toast.makeText(
                applicationContext,
                "Palavra errada, tente novamente!",
                Toast.LENGTH_SHORT
            ).show()
            count += 1
            nextBox?.requestFocus()
        }
        if(count == 5){
            binding.Certo.text = "A palavra era: $WORD"
            binding.Certo.visibility = View.VISIBLE
            binding.JNbut.visibility = View.VISIBLE
            binding.MEbut.visibility = View.VISIBLE
            makeGameInactive()
        }
    }

    private fun isWordInDictionary(word: String): Boolean {
        val sharedPreferences = getSharedPreferences("LinguaPrefs", Context.MODE_PRIVATE)
        val isCheckedPT = sharedPreferences.getBoolean("isCheckedPT", true)
        val isCheckedEN = sharedPreferences.getBoolean("isCheckedEN", true)
        val dicionarioPT = Dicionario().arrayPalavras5PT.split(", ")
        val dicionarioEN = DicionarioENG().arrayPalavras5EN.split(", ")
        if(isCheckedPT){
            return dicionarioPT.contains(word)
        } else if(isCheckedEN){
            return dicionarioEN.contains(word)
        }
        return false
    }

    private fun keepPassingFocus() {
        passFocusToNextbox(binding.box11, binding.box12)
        passFocusToNextbox(binding.box12, binding.box13)
        passFocusToNextbox(binding.box13, binding.box14)
        passFocusToNextbox(binding.box14, binding.box15)

        passFocusToNextbox(binding.box21, binding.box22)
        passFocusToNextbox(binding.box22, binding.box23)
        passFocusToNextbox(binding.box23, binding.box24)
        passFocusToNextbox(binding.box24, binding.box25)

        passFocusToNextbox(binding.box31, binding.box32)
        passFocusToNextbox(binding.box32, binding.box33)
        passFocusToNextbox(binding.box33, binding.box34)
        passFocusToNextbox(binding.box34, binding.box35)

        passFocusToNextbox(binding.box41, binding.box42)
        passFocusToNextbox(binding.box42, binding.box43)
        passFocusToNextbox(binding.box43, binding.box44)
        passFocusToNextbox(binding.box44, binding.box45)

        passFocusToNextbox(binding.box51, binding.box52)
        passFocusToNextbox(binding.box52, binding.box53)
        passFocusToNextbox(binding.box53, binding.box54)
        passFocusToNextbox(binding.box54, binding.box55)
    }

    private fun passFocusToNextbox(box1: EditText, box2: EditText) {
        box1.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (s?.length == 1) {
                    box2.requestFocus()
                }
            }
        })
    }

    private fun resetGame() {
        val sharedPreferences = getSharedPreferences("LinguaPrefs", Context.MODE_PRIVATE)
        val isCheckedPT = sharedPreferences.getBoolean("isCheckedPT", true)
        val isCheckedEN = sharedPreferences.getBoolean("isCheckedEN", true)
        count = 0
        if(isCheckedPT){
            WORD = Dicionario().arrayPalavras5PT.split(", ").random()
            Toast.makeText(
                applicationContext,
                "A palavra é: $WORD",
                Toast.LENGTH_SHORT
            ).show()
        }else if(isCheckedEN){
            WORD = DicionarioENG().arrayPalavras5EN.split(", ").random()
            Toast.makeText(
                applicationContext,
                "The word is: $WORD",
                Toast.LENGTH_SHORT
            ).show()
        }
        // Reset all EditText fields and their background colors
        val boxes = listOf(
            binding.box11, binding.box12, binding.box13, binding.box14, binding.box15,
            binding.box21, binding.box22, binding.box23, binding.box24, binding.box25,
            binding.box31, binding.box32, binding.box33, binding.box34, binding.box35,
            binding.box41, binding.box42, binding.box43, binding.box44, binding.box45,
            binding.box51, binding.box52, binding.box53, binding.box54, binding.box55
        )

        for (box in boxes) {
            box.text.clear()
            box.setBackgroundResource(R.drawable.wordle_border)
            box.isEnabled = true
        }

        binding.Certo.visibility = View.INVISIBLE
        binding.JNbut.visibility = View.INVISIBLE
        binding.MEbut.visibility = View.INVISIBLE
    }

    private fun saveScore() {
        databaseHelper.updateUserScore(username, pontuacao)
    }
}